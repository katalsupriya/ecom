export interface SearchModel {
  keyword?: string|unknown,
  max?:number,
  offset?:number,
  filterBy?:string
}