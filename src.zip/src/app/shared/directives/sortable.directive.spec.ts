/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SortableDirective } from './sortable.directive';

describe('Directive: Sortable', () => {
  it('should create an instance', () => {
    const directive = new SortableDirective();
    expect(directive).toBeTruthy();
  });
});
